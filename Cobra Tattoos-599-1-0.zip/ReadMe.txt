﻿This mods adds Cobra themed tattoos to your XCom game. Currently included are the Arashikage Clan tattoo, the Cobra and Iron Grenadiers logos, a Dreadnok tattoo (as seen on recent figures), a ColdSlither logo, a Crimson guard patch as a tattoo, a small Cobra Hydrofoil inspired sleeve tattoo and also a Dreadnok sleeve tattoo design. 

CREDITS: 
Thanks to UseYourIlusions for his Patterns, Face Paint and Tattoos tutorial that you can find here: 
https://www.youtube.com/watch?v=r73v1C0dnoU 

All original logos belong to Hasbro. The sleeve was made using artwork from G.I.Joe comic books. I am not entirely sure that the ColdSlither logo belongs to Hasbro. I’ll put due credit once I find whom it belongs to. I believe this would be considered fair use.
