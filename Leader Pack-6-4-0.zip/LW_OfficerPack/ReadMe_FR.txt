﻿Mod Chef d'XCOM pour XCOM 2
par Long War Studios

Ce mod ajoute une une possibilité d'amélioration pour les soldats d'XCOM qui peuvent désormais devenir "chefs". Un chef peut apprendre jusqu'à 5 capacités de chef, sur un total de 10 nouvelles capacités de chef.

- Les chefs sont débloqués via une amélioration de l'institut de guérilla. Cette amélioration peut être achetée quand au moins un des soldats du joueur a atteint le grade de sergent.
- L'amélioration de l'institut de guérilla débloque un emplacement d'entraînement pour former les soldats aux capacités de chef.
- Les soldats doivent avoir atteint un certain grade pour s'entraîner aux capacités de chef, à commencer par les sergents qui peuvent se former au premier niveau de chef.
- Un seul chef à la fois peut partir en mission, sauf certaines missions déséspérées (défense du Talion).
- De nombreuses capacités de chef utilisent le concept de "Portée de commandement" - cette portée augmente à mesure que le chef grimpe les échelons en s'entraînant à des capacités de chef supplémentaires.


----------------------------------

Installation manuelle du mod

1) Copiez les contenus du mod dans le dossier \Steam\steamapps\common\XCOM 2\XComGame\Mods\

Désinstallation manuelle du mod
1) Supprimez le dossier \Steam\steamapps\common\XCOM 2\XComGame\Mods\LW_LeaderPack\