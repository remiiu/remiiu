﻿Long War PerkPack
By Long War Studios
http://www.longwarstudios.com

This mod adds more than 70 new and reworked abilities to assign to soldiers, gear or aliens, adds UI support for choosing between three perks per soldier level as well as additional levels, reworks the four base classes into seven, and adds 10 new PCS items with perks. Players are invited to create their own classes using these abilities. 

It also reworks the tactical HUD -- the list of ability icons you can activate -- to handle more than 14 abilities at once.

INSTRUCTIONS FOR INSTALLATION 
Steam Workshop: Subscribe to the mod in the Long War Studios workshop page.

Manual/Nexus: From the zip archive, place the folder LW_PerkPack and its contents into your version of the C:\Program Files (x86)\Steam\steamapps\common\XCOM 2\XComGame\Mods folder.

To play:
Check the LW_PerkPack mod in the launcher. 

Note: This mod has some options-menu controlled configuration settings that only appear if you have Long War Toolbox installed. The mod's primary functionality does not require Toolbox to be installed.

----------------------------------------------
----------------- CREDITS --------------------
----------------------------------------------

Design Lead / Programmer: John Lumpkin
Technical Lead: Rachel "Amineri" Norman
Artwork: Dana Henderson (http://www.danaillustration.com/)
Playtesting: Tim "Bilfdoffle" Evans, Lance D. Allen

---------------------------------------------
----------------PERMISSIONS------------------
---------------------------------------------

Modders are free to incorporate any code or other assets from this mod in their own, provided credit is given to Long War Studios in the appropriate places in mod releases.

----------------------------------------------
--------------- COMPATIBILITY ----------------
----------------------------------------------

This mod overrides some base classes and will not be compatible with other mods that do the same. They are
* UIArmory_MainMenu
* UIInventory_Implants

----------------------------------------------
----------------- NOTES ----------------------
----------------------------------------------

NEW AND REWORKED CLASSES

SHARPSHOOTER -- While similar to base-game sharpshooter, the player may also take Snap Shot, which turns the sniper into a mobile marksman. Starts with Squadsight.
RANGER -- A pure rifleman, with a pistol as a sidearm. Starts with Light 'Em Up.
ASSAULT -- A shotgun specialist similar to the EU/EW assault, with a sword as a secondary weapon. Starts with Run N' Gun.
SHINOBI -- A stealth, mobility and sword specialist. Can carry rifles or shotguns as a primary weapon. Starts with Phantom.
SPECIALIST -- Similar to base-game specialist. Starts with Haywire Protocol and Aid Protocol.
GUNNER -- Carries a cannon and a pistol. Perks focus on a variety of special shots. Starts with Area Suppression.
GRENADIER -- Carries a rifle or shotgun as a primary weapon, grenade launcher as a secondary. Adds a number of abilities allowing the grenadier to specialize in support or damaging grenades. Starts with Launch Grenade.

Adding this mod to an existing campaign will not change existing soldiers, and new soldiers will only sort into the new class trees. Many perks may also be acquired by the Advanced Warfare Center.

NEW PERKS

Aggression: Gain +5 critical chance for each enemy you can see, up to a maximum of 30.
Airdrop: Grants an explosive grenade to the targeted ally.
Area Suppression: Fire a barrage that pins down multiple targets within a 3-tile radius, granting reaction fire against the first one that moves, and imposing a penalty all targets' aim until suppression is removed.
Bastion: Fortress now provides immunity to nearby teammates.
Body Shield: A targeted enemy receives -20 aim and -50 critical chance against the soldier.
Boosted Cores: Explosive grenades do one additional damage.
Bring 'Em On: Gain +1 damage on critical hits for each enemy you can see, up to a maximum of +8.
Center Mass: You do one additional point of base damage with your primary weapon.
Close and Personal: Confers +30 critical chance against adjacent targets. The bonus declines with distance from the target.
Close Combat Specialist: During enemy turns, fire a free reaction shot with your primary weapon at any visible enemy within four tiles who moves or fires.
Close Encounters: Once per turn, gain a bonus action after taking a standard shot with your primary weapon at an enemy within four tiles.
Clutch Shot: Once per mission, fire a pistol shot that cannot miss.
Combat Awareness: Grants 15 defense and half an armor point when in overwatch.
Combat Rush: "When you kill an enemy, nearby allies temporarily receive bonuses to aim, critical chance and mobility. Five-turn cooldown.
Commissar: Pistol shots against allies who have been mind-controlled by enemies have +50 to hit, cannot be dodged, and automatically kill the target if a hit occurs.
Covert: Enemies have 20% smaller detection range against you.
Cutthroat: Your melee attacks against biological enemies ignore their armor and have a +10 critical chance.
Cyclic Fire: Special Shot: Fire three shots at a target in a single attack. Requires both actions and all shots have aim penalties. Four-turn cooldown.
Damage Control: After taking damage, gain two armor through the end of the next turn.
Damn Good Ground: Confers +10 aim and +10 defense against targets at a lower elevation.
Danger Zone: Area Suppression suppresses enemies in a 5-tile radius.
Dense Smoke: Your smoke grenades confer an additional 20 defense.
Depth Perception: Gain 5 aim and reduce enemies' dodge by 25 when at a higher elevation than your target.
Double Tap: Special shot: Fire two shots with your primary weapon at the same target. Requires both actions. Second shot is at a -10 aim penalty.
Emergency Life Support: Ensures the first killing blow in a mission will not lead to instant death. It also extends the time before the soldier bleeds out and dies.
Evasive: Start each mission with 100 bonus dodge. The bonus is removed after you take damage for the first time.
Executioner: Confers +10 aim and +10 critical chance against targets at half or less of their original hit points.
Extra Conditioning: Run and Gun cooldown is reduced by one turn.
Field Surgeon: Reduce wound recovery times for most soldiers.
Flashbanger: Grants 1 free flashbang item to your inventory.
Fleche: Attack any enemy within movement range with your sword. Deals +1 damage for every 4 tiles between your starting position and the target.
Formidable: Your gear includes an extra layer of protection, granting a bonus point of Armor and reduced damage from explosive attacks.
Full Kit: Grants +1 charge per grenade item in a utility slot.
Ghostwalker: Activate this ability to reduce enemy detection range by 40% for the rest of your turn as well as the following turn. Five-turn cooldown.
Grazing Fire: Missed shots with your primary weapon get an additional roll to become a graze.
Gunslinger: Take a reaction shot with your pistol against any enemy that moves or attacks within 8 tiles and a wide cone of fire.
Hard Target: Gain 5 dodge per enemy you can see, up to a maximum of +50.
Hit and Run: Once per turn, gain an additional move action after taking a standard shot at a flanked or exposed target with your primary weapon. 
Hyper-Reactive Pupils: Gain +10 aim for your next shot with your primary weapon after a miss.
Impact Fields: Activate a force field that reduces incoming damage by 33% for two turns. Six-turn cooldown.
Infighter: Gain 25 dodge against attacks within four tiles.
Interference: Gremlin cancels overwatch on targeted unit. Use three times per battle.
Iron Curtain: Special shot that does half damage but reduces target mobility for the following two turns. Cone-based attack with primary weapon.
Iron Skin: Incoming melee damage is reduced by 3.
Killer Instinct: Activating Run & Gun grants +50% critical damage for the rest of the turn.
Kubikuri: Special shot against most enemies who have taken any damage: Any critical hit kills them, but regular hits do half damage. Requires two actions and has a 4-turn cooldown.
Lethal: You do two additional points of base damage with your primary weapon.
Light 'Em Up: Taking a standard shot with your primary weapon as your first action no longer ends your turn.
Lightning Reflexes_LW: Reaction fire shots against you have a significantly decreased chance to hit. The bonus goes down with each additional reaction shot you face.
Lockdown: +50 to hit and 50% bonus damage against enemies who attempt to move when suppressed.
Locked On: Gain +10 aim for successive shots at the same enemy unit.
Lone Wolf: Gain +10 aim and +10 defense when 7 or more tiles distant from any ally.
Low Profile: Makes partial cover count as full.
Mind Merge: Grants bonus will and ablative hit points to an ally until the beginning of the player's next turn.
Precision Shot: Take a special shot with +30 bonus to critical chance and 33% bonus critical damage. Three-turn cooldown.
Rapid Deployment: Activate this ability before throwing or launching a support grenade, and the throw will not cost an action.
Rapid Reaction: When in overwatch, each shot you hit with grants another reaction fire shot, up to a maximum of three shots.
Resilience: Enemy attacks against you suffer a -50 penalty to critical hit chances.
RunAndGun_LW: Unchanged from vanilla but required to work with other abilities.
Savior: Healing abilities restore four additional hit points.
Sentinel_LW: When in overwatch, you may take two reaction shots.
Slash_LW: Attack an adjacent target with your sword. Uses one action.
Slug Shot: Special shot for primary-weapon shotguns only: Fire a shot with no range penalties. Uses two ammo. Five-turn cooldown.
Smart Macrophages: Heals injuries after a battle, lowering wound recovery time, and confers immunity to poison and acid.
Smoker: Grants one free smoke grenade item to your inventory.
Soul Merge: Increases effectiveness of Mind Merge by conferring larger bonuses to will and ablative hit points and reducing its cooldown period.
Snap Shot: You may take standard shots and enter standard overwatch with your sniper rifle after moving, but you suffer severe range penalties beyond 5 tiles of squadsight range on all shots.
Steady Weapon: Gain +20 aim on your next shot with your primary weapon. Bonus is lost if you use actions or are wounded.
Sting Grenades: Your flashbang grenades have a chance to stun enemies.
Suppression_LW: Unchanged from vanilla but new version required to work with other abilities.
Tactical Sense: Gain 5 defense for each enemy you can see, up to a maximum of 20 defense.
Traverse Fire: After taking a standard shot with your primary weapon with your first action, you may take an additional non-movement action.
Trench Gun: Special shot for primary-weapon shotguns only: Fire a short-range cone-based attack at nearby targets. Three-turn cooldown.
Trojan: Enemy units that are hacked take damage and lose their actions on the turn the hack effect ends.
Walk Fire: Take a highly accurate shot with +30 bonus to hit but for half damage and -30 crit. Uses 2 ammo.
Will to Survive: Enemy damage is reduced by 1 when in cover and attacked through that cover.

New items, collectible as loot during missions
Depth Perception PCS
Hyper-Reactive Pupils PCS
Combat Awareness PCS
Combat Rush PCS
Impact Fields PCS
Damage Control PCS
Body Shield PCS
Emergency Life Support PCS
Iron Skin PCS
Smart Macrophages PCS
