﻿Mod capi per XCOM2
Di Long War Studios

Questo mod aggiunge un percorso di sviluppo dei soldati XCOM, che ora hanno la possibilità di diventare "capi". I capi possono scegliere tra 10 nuove abilità, con un massimo di 5 per capo.

- I capi si sbloccano tramite un potenziamento della scuola di guerriglia. Il potenziamento diventa acquistabile quando il giocatore ha raggiunto il grado di sergente con almeno un soldato.
- Il potenziamento alla scuola di guerriglia sblocca uno slot di addestramento per le abilità da capo.
- I soldati devono avere un grado minimo per potersi addestrare con i livelli da capo, a partire dai sergenti, che possono addestrarsi per il primo livello.
- A meno che non si presenti una situazione particolare, si può portare un solo capo per volta in missione.
- Molte abilità da capo sfruttano il concetto di "Portata di comando": la portata aumenta mano a mano che si ottengono livelli da capo, addestrando abilità da capo aggiuntive


----------------------------------

Installazione manuale del mod

1) Copiare i contenuti del pacchetto del mod nella cartella \Steam\steamapps\common\XCOM 2\XComGame\Mods\

Disinstallazione manuale del mod
2) Eliminare la cartella \Steam\steamapps\common\XCOM 2\XComGame\Mods\LW_OfficerPack\