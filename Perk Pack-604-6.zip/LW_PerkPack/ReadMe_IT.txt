Long War PerkPack
Di Long War Studios
http://www.longwarstudios.com

Questo mod aggiunge pi� di 70 abilit� nuove o riviste da assegnare a soldati, attrezzature o alieni; aggiunge un'interfaccia per scegliere tra tre abilit� per livello del soldato; aggiunge livelli; modifica le quattro classi base ricavandone sette; aggiunge 10 nuove SCP con abilit�. I giocatori sono invitati a creare le loro classi usando queste abilit�. 

Rivede anche l'interfaccia tattica, la lista con le icone abilit� da attivare, in modo che possa gestire pi� di 14 abilit� contemporaneamente.

ISTRUZIONI PER L'INSTALLAZIONE 
Steam Workshop: iscriviti al mod nella pagina del workshop di Long War Studios.

Manuale/Nexus: dall'archivio zip, posiziona la cartella LW_PerkPack e i suoi contenuti nella tua versione della cartella C:\Programmi (x86)\Steam\steamapps\common\XCOM 2\XComGame\Mods folder.

Per giocare:
Spunta LW_PerkPack mod nel launcher. 

Nota: questo mod ha alcune impostazioni che appaiono solo se � installato Long War Toolbox. Le funzionalit� principali del mod non richiedono Toolbox.

---------------------------------------------- 
----------------- RICONOSCIMENTI --------------------
----------------------------------------------

Capo progettazione/Programmazione: John Lumpkin
Capo tecnico: Rachel "Amineri" Norman
Grafica: Dana Henderson (http://www.danaillustration.com/)
Tester: Tim "Bilfdoffle" Evans

---------------------------------------------
----------------PERMESSI------------------
---------------------------------------------

I modder possono incorporare il codice e gli asset di questo mod nei propri mod, a patto che li attribuiscano a Long War Studios nelle sezioni appropriate.

----------------------------------------------
--------------- COMPATIBILIT� ----------------
----------------------------------------------

Questo mod modifica alcune classi base e non sar� compatibile con gli altri mod che fanno la stessa cosa. Si tratta di
* UIArmory_MainMenu
* UIInventory_Implants

----------------------------------------------
----------------- NOTE ----------------------
----------------------------------------------

CLASSI NUOVE E RIVISTE

TIRATORE SCELTO -- Pur essendo simile al tiratore scelto del gioco base, permette al giocatore di usare il colpo veloce, che trasforma il cecchino in un tiratore mobile. Parte con visuale di squadra.
RANGER -- Un fuciliere puro, con una pistola come arma secondaria. Parte con Fuoco a volont�.
ASSALTO -- Specialista dello shotgun, simile all'unit� d'assalto di EU/EW, con una spada come arma secondaria. Parte con Fuoco in corsa.
SHINOBI -- Uno specialista delle spade che eccelle nella furtivit� e nella mobilit�. Pu� usare fucili o shotgun come armi primarie. Parte con Fantasma.
SPECIALISTA -- Simile allo specialista del gioco base. Parte con Protocollo di controllo e Protocollo di supporto.
MITRAGLIERE -- Ha un cannone e una pistola. Le abilit� si concentrano su una serie di colpi speciali.
GRANATIERE -- Ha un fucile o uno shotgun come arma primaria e un lanciagranate come arma secondaria. Aggiunge una serie di abilit� che consentono al granatiere di specializzarsi nelle granate di supporto o in quelle d'attacco.

Aggiungere questo mod a una campagna esistente non modifica i soldati esistenti. Solo i nuovi soldati useranno le nuove classi. Molte abilit� possono essere ottenute anche con il Centro bellico avanzato.

NUOVE ABILIT�

Campi di assorbimento
Aggressione
Sgancio aereo
Soppressione ad area
Bastione
Fatevi sotto
Centro di massa
Stretto contatto
Specialista ravvicinato
Incontri ravvicinati
Colpo cruciale
Percezione in combattimento
Brivido del combattimento
Commissario
Operazione segreta
Tagliagole
Fuoco ciclico
Controllo dei danni
Ottima posizione
Zona di pericolo
Fumo impenetrabile
Percezione della profondit�
Doppio colpo
Supporto vitale di emergenza
Sfuggente
Boia
Preparazione extra
Chirurgo da campo
Pi� flashbang
Fl�che
Kit completo
Passo felino
Fuoco graffiante
Pistolero
Bersaglio difficile
Granate pesanti
Mordi e fuggi
Pupille iper-reattive
Riflessi ravvicinati
Interferenza
Cortina di ferro
Pelle di ferro
Istinto omicida
Kubikuri
Letale
Fuoco a volont�
Riflessi fulminei
Blocco totale
Bersaglio acquisito
Lupo solitario
Basso profilo
Colpo preciso
Lancio rapido
Reazione rapida
Resistenza
Fuoco in corsa
Salvatore
Sentinella
Lacerazione
Proiettile slug
Macrofagi intelligenti
Granata fumogena
Colpo veloce
Arma stabilizzata
Granate pungenti
Soppressione
Senso tattico
Fuoco esteso
Fucile da trincea
Sgobbone
Tiro corretto
Voglia di sopravvivere

Nuovi oggetti, elementi da raccogliere durante le missioni
SCP: Percezione della profondit�
SCP: Pupille iper-reattive
SCP: Percezione in combattimento
SCP: Brivido del combattimento
SCP: Campi di assorbimento
SCP: Controllo dei danni
SCP: Scudo corporeo
SCP: Supporto vitale di emergenza
SCP: Pelle di ferro
SCP: Macrofagi intelligenti
