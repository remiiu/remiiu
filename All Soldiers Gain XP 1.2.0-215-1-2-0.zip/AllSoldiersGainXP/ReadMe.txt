﻿Install by extracting files to Steam\steamapps\common\XCOM 2\XComGame\Mods

...or use Nexus Mod Manager!