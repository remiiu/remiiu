﻿Tracks and displays the actions and successes of your soldiers throughout their campaign. 
Now you can know for sure whether or not your favorite sniper has truely ever missed! 

FREQUENTLY ASKED QUESTIONS
Q: Why don't I see the stats panel during combat? 
A: The stats panel only shows when you hover your mouse over the Hit% of a shot. You can make it always displayed by editing the INI file. 

Q: Why is 'But Probably...' in my shot window? Does this modify my chance to hit? 
A: That is a fun way to visualize how lucky this soldier is. It is just a visual change and does not impact actual dice rolls. You can disable it via the INI file. 

Q: Why doesn't my Armory stats panel line up right like in your screenshot? 
A: Known bug with non 16:9 resolutions. I am looking into it but in the meantime you can offset the window to the right or down by editing the INI file. Suggested panelXOffest=320 for 21:9 (Thanks Dem0nK!) 

Q: Can I change what is shown in the tactical/armory stats panel?
A: Yes! You can change which stats get shown and the order for both panels in the INI

Q: Where is this magic INI file you speak of so I can edit all of these things? 
A: steamapps\workshop\content\268500\634754304\Config\LifetimeStats.ini 

Q: What is Lucky% and how do you compute it? 
A: It is how often this soldier beats the RNG. See below for the full algorithm with examples. 

VERSION 1.2.2
March 21th

Fixed bug causing camera to reset whenever soldiers reach their destination from normal movements
Updated Polish Localization
-------------
Updated Russian and Korean Localizaton
-------------
Fixed bug that was preventing stats to be saved across saves.  Unfortunately stats were not properly tracked
between v1.0.0 and now and are lost.  I apologize for the inconvenience.

CURRENT FEATURES
Tracked Data: (can configure which and in what order they get shown in via INI) 
Kills - Every kill made by a soldier (not part of mod, already tracked by base game) 
Shots - Every shot taken by a soldier (includes sword attacks)
Hits/Misses - Whether the shot Hit or Missed
Hit/Miss Streaks - The current and best Hit and Miss streaks for this soldier
Crits - How many shots have Crit 
Avg Hit % - The average hit chance over all shots taken 
Avg Crit % - The average crit chance over all shots taken 
Luck - Luck is computed by comparing Hits to Avg Hit%, see below for more details
Tiles Moved - The total number of tiles moved by a soldier
Executions - Number of repeater executions
Damage - Amount of damage dealt
Damage Taken - Amount of damage taken
Damage Negated - Amount of damage dealt blocked by armor
Damage Absorbed - Amount of damage taken blocked by armor

Tactical Lifetime Stats hover tooltip (or permanent panel via INI tweak) 
A new panel has been added to Tactical Combat missions showing all tracked data visible by hovering over the current Hit% of a shot. 

Luck Modified ToHit % (can disable in INI) 
A new Hit% is now displayed next to the existing Hit% for all shots showing how likely this particular soldier is to hit given the actual hit chance and also their luck. 

Armory Stats Screen 
A new window located on the soldier screen in the Armory shows the stats of the currently selected soldier 

COMPUTED VALUES
Due to popular demand, here are the algorithms I am using to calculate Luck and 'But Probably...' 

Luck = Hits / (AverageHit% * Shots) - 1 
If this value is less than zero, I show it as positive but 'Unlucky' 
Example: AvgHit% = 80, Hits = 10, Shots = 10 
Luck = 10 / (10 * 0.80) = 1.25 - 1 = 0.25 or 25% lucky 

'But Probably...' = Hit% * (Luck+1)	
Example: Hit% = 70%, Luck = 25% 
'But Probably...' = 70 * 1.25 = 87.5 

PLANNED FEATURES
http://steamcommunity.com/workshop/filedetails/discussion/634754304/412448792349337145/ 
POSSIBLE FEATURES
http://steamcommunity.com/workshop/filedetails/discussion/634754304/412448792349342862/ 
BUG REPORTS
http://steamcommunity.com/workshop/filedetails/discussion/634754304/412448792349339624/ 

KNOWN ISSUES
Resolutions other than 16:9 cause the armory window to display incorrectly. You can manually edit the position of the window in the INI file 
as a temporary fix. 

COMPATIBILITY
This mod uses UIScreenListeners and events and overrides no classes. 
It listens to UITacticalHUD and UIArmory_MainMenu, if a mod overrides these classes there may be issues 
I have yet to find an incompatible mod.