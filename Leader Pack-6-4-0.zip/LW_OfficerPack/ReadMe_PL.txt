﻿Modyfikacja: przywódca dla XCOM 2
Autorstwa Long War Studios

Ta modyfikacja powoduje, że żołnierze XCOM mogą stawać się "przywódcami". Przywódca ma dostęp do 10 nowych zdolności i może się nauczyć maksymalnie 5 z nich.

- Przywódców odblokowuje się za pomocą ulepszenia szkoły działań partyzanckich. To ulepszenie można kupić, gdy przynajmniej jeden żołnierz gracza osiągnął stopień sierżanta.
- Ulepszenie szkoły działań partyzanckich odblokowuje miejsce do uczenia żołnierzy zdolności przywódcy.
- Żołnierze muszą mieć odpowiedni stopień podstawowy, żeby nauczyć się atutu przywódcy. Pierwszy poziom przywódcy jest dostępny od stopnia sierżanta.
- Oprócz sytuacji krytycznych w misji może brać udział tylko jeden przywódca.
- Wiele zdolności przywódcy korzysta z pojęcia "zasięgu dowodzenia", rosnącego wraz z rozwojem rangi poprzez poznawanie dodatkowych zdolności przywódcy.


----------------------------------

Ręczna instalacja modyfikacji
1) Skopiuj zawartość pakietu modyfikacji do folderu \Steam\steamapps\common\XCOM 2\XComGame\Mods\

Ręczne usuwanie modyfikacji
1) Usuń folder \Steam\steamapps\common\XCOM 2\XComGame\Mods\XCOMLeaderPack\
