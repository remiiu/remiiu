﻿Zestaw atutów Long War
Stworzone przez Long War Studios
http://www.longwarstudios.com

The mod dodaje ponad 70 nowych i zmienionych zdolności, które można przypisać żołnierzom, obcym oraz broni. Zawiera on również interfejs obsługujący trzy atuty na poziom żołnierza oraz dodatkowe poziomy, rozbudowuje cztery podstawowe klasy na siedem, a także zapewnia 10 nowych PSB z atutami. Zachęcamy graczy do tworzenia własnych klas z tymi zdolnościami. 

Mod zmienia interfejs taktyczny – czyli listę ikonek, które można aktywować – dzięki czemu obsługuje on więcej niż 14 zdolności.

INSTRUKCJA INSTALACJI 
Steam Workshop: subskrybuj mod na stronie Long War Studios.

Ręcznie/Nexus: rozpakuj archiwum zip, umieść folder LW_PerkPack i jego zawartość w Twojej wersji ścieżki C:\Program Files (x86)\Steam\steamapps\common\XCOM 2\XComGame\Mods.

Aby zagrać:
Zaznacz mod LW_PerkPack w programie startowym. 

Uwaga: ten mod zawiera kilka ustawień dostępnych z menu opcji, ale pojawią się one tylko wówczas, gdy masz zainstalowany zestaw narzędzi Long War. Sam mod nie wymaga go jednak do działania.

---------------------------------------------- 
-----------------AUTORZY---------------------
----------------------------------------------

Główny projektant i programista: John Lumpkin
Kierownik techniczna: Rachel „Amineri” Norman
Projekt graficzny: Dana Henderson (http://www.danaillustration.com/)
Testowanie: Tim „Bilfdoffle” Evans

---------------------------------------------
----------------ZEZWOLENIA------------------
---------------------------------------------

Moderzy mogą wykorzystywać dowolny kod i inne materiały z tego modu pod warunkiem, że zaznaczą w odpowiednich miejscach opublikowanego modu informację o wykorzystaniu materiałów Long War Studios.

----------------------------------------------
--------------- KOMPATYBILNOŚĆ -----------------
----------------------------------------------

Ten mod zmienia niektóre klasy z wersji podstawowej i nie będzie działać z innymi modami, które robią to samo. Oto one:
* UIArmory_MainMenu
* UIInventory_Implants

----------------------------------------------
----------------- UWAGI ----------------------
----------------------------------------------

NOWE I ZMIENIONE KLASY

STRZELEC WYBOROWY – podobny do tej samej klasy z podstawki, ale gracz może wybrać „szybki strzał”, który zmienia go w mobilnego snajpera. Zaczyna ze zdolnością „widok drużynowy”.
ŁOWCA – posługuje się karabinami i pistoletem przybocznym. Zaczyna ze zdolnością „walcie do nich”.
SZTURMOWIEC – specjalista od strzelb podobny do szturmowca z EU/EW. Posiada również miecz i zaczyna ze zdolnością „strzelanie w biegu”.
SHINOBI – specjalista od kamuflażu, mobilności i mieczy. Może używać karabinów i strzelb jako broni głównej. Zaczyna ze zdolnością „fantom”.
SPECJALISTA – przypomina specjalistę z podstawki. Zaczyna ze zdolnościami „protokół przechwytujący” i „protokół wsparcia”.
STRZELEC – niesie działko oraz pistolet. Atuty obracają się wokół różnych strzałów specjalnych.
GRENADIER – niesie karabin lub strzelbę jako broń główną, granatnik jako broń zapasową. Mod daje mu kilka zdolności pozwalających na specjalizację w granatach ofensywnych lub wsparcia.

Dodatnie tego modu do trwającej kampanii nie zmieni obecnych w niej żołnierzy, ale nowi będą już dopasowani do nowych drzewek zdolności. Wiele atutów można zdobyć również w ośrodku taktyk zaawansowanych.

NOWE ATUTY

Pola absorpcyjne
Agresja
Zrzut zaopatrzenia
Przygwożdżenie obszarowe
Twierdza
Dajcie mi ich
Środek ciężkości
Z bliska
Specjalista od walki bezpośredniej
Bliskie spotkania
Pewny strzał
Zmysł bojowy
Gorączka walki
Komisarz
Skrytość
Rzezimieszek
Szybki ostrzał
Ograniczenie szkód
Cholernie dobry teren
Strefa zagrożenia
Gęsty dym
Postrzeganie głębi
Dublet
Podtrzymywanie życia
Nieuchwytny
Kat
Trening kondycyjny
Lekarz polowy
Błyskomistrz
Wypad
Pełny arsenał
Bezszelestny
Draśnięcie
Rewolwerowiec
Trudny cel
Ciężkie granaty odłamkowe
Atak i odskok
Hiperreaktywne źrenice
Zwarcie
Rozproszenie
Żelazna kurtyna
Żelazna skóra
Instynkt zabójcy
Kubikiri
Zabójczy
Walcie do nich
Błyskawiczny refleks
Blokada
Cel namierzony
Samotny wilk
Skrytość
Precyzyjny strzał
Szybkie użycie
Błyskawiczna reakcja
Wytrzymałość
Strzelanie w biegu
Zbawca
Strażnik
Cięcie
Breneka
Inteligentne makrofagi
Granat dymny
Szybki strzał
Stabilizacja broni
Granaty igłowe
Przygwożdżenie
Zmysł taktyczny
Przeniesienie ostrzału
Strzelba bojowa
Trojan
Strzelanie w ruchu
Instynkt przetrwania

Nowe przedmioty do zdobycia jako łub na misjach
PSB: postrzeganie głębi
PSB: hiperreaktywne źrenice
PSB: zmysł bojowy
PSB: gorączka walki
PSB: pola absorpcyjne
PSB: ograniczenie szkód
PSB: pancerz ochronny
PSB: podtrzymywanie życia
PSB: żelazna skóra
PSB: inteligentne makrofagi
