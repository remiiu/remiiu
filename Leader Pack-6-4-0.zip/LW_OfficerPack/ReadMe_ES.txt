﻿Mod de líder de XCOM para XCOM 2
Por Long War Studios

Este mod añade la mejora de "líder" para los soldados del juego. Los líderes cuentan con una serie de 10 habilidades nuevas para elegir, de las que cada líder podrá aprender hasta 5.

- Los líderes se desbloquean con una mejora de la escuela de tácticas de guerrilla. El jugador podrá comprar esta mejora cuando al menos uno de sus soldados haya alcanzado el rango de sargento.
- La mejora de la escuela de tácticas de guerrilla desbloquea un espacio de entrenamiento para entrenar a soldados con habilidades de líder.
- Los soldados deben tener el rango inicial apropiado para poder entrenarse en una mejora de líder, empezando por los sargentos, que podrán entrenarse en el primer nivel de líder.
- Solo se puede llevar a un líder en cada misión, excepto en situaciones de emergencia críticas.
- Muchas habilidades de líder usan el concepto de "distancia de mando". Esta distancia aumenta a medida que el líder sube de rango de líder entrenando habilidades de líder adicionales.


----------------------------------

Instalar el mod manualmente

1) Copia el contenido del paquete del mod al directorio \Steam\steamapps\common\XCOM 2\XComGame\Mods\

Desinstalar el mod manualmente

1) Elimina la carpeta \Steam\steamapps\common\XCOM 2\XComGame\Mods\XCOMLeaderPack\
