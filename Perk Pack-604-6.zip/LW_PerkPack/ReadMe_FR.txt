﻿Long War PerkPack
Par Long War Studios
http://www.longwarstudios.com

Ce mod propose plus de 70 capacités nouvelles et retravaillées à assigner aux soldats, à votre équipement ou aux extraterrestres, une assistance pour l'interface utilisateur afin de choisir parmi trois atouts par niveau de soldat ainsi que des niveaux supplémentaires, sept classes de jeu au lieu des quatre classes de base, et 10 nouveaux objets SPC (atouts). Les joueurs sont invités à créer leurs propres classes à l'aide de ces capacités. 

Ce mod propose aussi une version retravaillée de l'ATH tactique -- la liste des icônes des capacités que vous pouvez activer -- pour gérer plus de 14 capacités à la fois.

INSTRUCTIONS D'INSTALLATION
Steam Workshop : abonnez-vous au mod sur le Workshop de Long War Studios.

Manuelle/Nexus : ouvrez l'archive et copiez le répertoire LW_PerkPack ainsi que son contenu dans votre version du dossier C:\Program Files (x86)\Steam\steamapps\common\XCOM 2\XComGame\Mods.

Pour jouer :
Cochez le mod LW_PerkPack dans le Launcher. 

Remarque : Ce mod utilise des paramètres de configuration liés à certaines options qui n'apparaissent que si vous avez installé Long War Toolbox. La fonction principale de ce mod ne nécessite toutefois pas l'installation de Toolbox.

---------------------------------------------- 
----------------- CRÉDITS --------------------
----------------------------------------------

Programmeur / Concepteur en chef : John Lumpkin
Responsable technique : Rachel "Amineri" Norman
Responsable artistique : Dana Henderson (http://www.danaillustration.com/)
Playtest : Tim "Bilfdoffle" Evans

---------------------------------------------
----------------AUTORISATIONS------------------
---------------------------------------------

Les modders sont libres d'intégrer tout code ou tout élément de ce mod comme bon leur semble, dans la mesure où Long War Studios apparaît clairement dans les crédits du mod ainsi créé.

----------------------------------------------
--------------- COMPATIBILITÉ ----------------
----------------------------------------------

Ce mod modifie certaines classes de base et ne sera pas compatible avec tout autre mod faisant de même :
* UIArmory_MainMenu
* UIInventory_Implants

----------------------------------------------
----------------- REMARQUES ----------------------
----------------------------------------------

CLASSES NOUVELLES ET RETRAVAILLÉES

TIREUR D'ÉLITE -- Bien que similaire au Tireur d'élite du jeu de base, le joueur peut aussi utiliser le Tir éclair, qui transforme le Tireur d'élite en Flingueur mobile. Commence avec Vision commune.
RANGER -- Virtuose du fusil, avec un pistolet en guise d'arme de poing. Commence avec Allumage.
COMMANDO -- Spécialiste du fusil à pompe, avec une épée en arme secondaire. Commence avec Course et tir.
SHINOBI -- Spécialiste de la discrétion, de la mobilité et de l'épée. Peut porter un fusil ou un fusil à pompe comme arme principale. Commence avec  Fantôme.
SPÉCIALISTE -- Similaire au spécialiste du jeu de base. Commence avec Protocole de détraquage et Protocole de soutien.
GUNNER -- Porte un canon et un pistolet. Ses atouts se concentrent sur une variété de tirs spéciaux.
GRENADIER -- Porte un fusil ou un fusil à pompe comme arme principale, et un lance-grenades comme arme secondaire. Ajoute un nombre de capacités permettant au grenadier de se spécialiser en grenades de soutien.

L'ajout de ce mod à une campagne en cours ne modifiera pas les soldats existants. Les nouveaux soldats ne pourront figurer que dans les nouveaux arbres de classes. De nombreux atouts peuvent aussi être acquis par le centre de combat amélioré.

NOUVEAUX ATOUTS

Champs d'absorption
Agressivité
Largage
Suppression de zone
Bastion
Viens par là
Masse centrée
Proximité mortelle
Spécialiste en combat rapproché
Affrontement rapproché
Tir crucial
Attention accrue
Adrénaline
Commissaire
Couverture
Coupe-gorge
Tir cyclique
Contrôle des dégâts
Avantage du terrain
Zone de danger
Fumée dense
Perception de profondeur
Double tir
Premiers soins
Évasion
Bourreau
Conditionnement supplémentaire
Chirurgien de terrain
Flashouilleur
Flèche
Kit complet
Marche spectrale
Égratignure
Fin tireur
Cible difficile
Noyaux explosifs
Frappe et course
Pupilles hyper-réactives
Corps à corps
Interférence
Rideau de fer
Impénétrable
Instinct de tueur
Kubikiri
Létal
Allumage
Réflexes éclair
Geôlier
Verrouillage
Loup solitaire
Profil bas
Tir précis
Déploiement rapide
Réaction rapide
Résilience
Course et tir
Sauveur
Sentinelle
Lacération
Tir imprécis
Macrophages intelligentes
Fumigène
Tir éclair
Arme stable
Grenades incapacitantes
Suppression
Sens tactique
Tir de traverse
Arme de tranchée
Troyen
Cible mobile
Volonté de survie

Nouveaux objets à récupérer comme butin au cours des missions
SPC : Perception de profondeur
SPC : Pupilles hyper-réactives
SPC : Attention accrue
SPC : Adrénaline
SPC : Champs d'absorption
SPC : Contrôle des dégâts
SPC : Bouclier corporel
SPC : Premiers soins
SPC : Impénétrable
SPC : Macrophages intelligentes
