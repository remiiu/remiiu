﻿Pack de mejoras de Long War
Por Long War Studios
http://www.longwarstudios.com

Este mod añade más de 70 habilidades nuevas o remodeladas para asignar a soldados, equipo o alienígenas, añade soporte de interfaz para poder elegir entre tres ventajas por nivel de soldado, así como niveles adicionales, adapta las cuatro clases básicas y las amplía hasta siete, y añade 10 nuevos objetos de SCP con mejoras. Invitamos a los jugadores a crear sus propias clases usando estas habilidades. 

También adapta la interfaz táctica, la lista de iconos de habilidad que pueden activarse, para que pueda incluir más de 14 habilidades al mismo tiempo.

INSTRUCCIONES DE INSTALACIÓN 
Steam Workshop: suscríbete al mod en la página de Steam Workshop de Long War Studios.

Manual/Nexus: desde el archivo comprimido, coloca la carpeta LW_PerkPack y sus contenidos en tu versión de la carpeta C:\Archivos de programa (x86)\Steam\steamapps\common\XCOM 2\XComGame\Mods.

Para jugar:
Activa el mod LW_PerkPack en el programa de inicio. 

Nota: este mod tiene algunos ajustes de configuración controlados mediante el menú de opciones que solo aparecen si tienes activadas las Herramientas de Long War. La funcionalidad principal de este mod no necesita que las Herramientas estén instaladas.

---------------------------------------------- 
----------------- CRÉDITOS --------------------
----------------------------------------------

Jefe de diseño/Programador: John Lumpkin
Jefa de diseño técnico: Rachel "Amineri" Norman
Ilustraciones: Dana Henderson (http://www.danaillustration.com/)
Pruebas de juego: Tim "Bilfdoffle" Evans

---------------------------------------------
----------------PERMISOS------------------
---------------------------------------------

Los modders tienen libertad para incorporar cualquier código o recursos de este mod a los suyos, siempre que reconozcan el mérito a Long War Studios en los lugares apropiados de las publicaciones de mods.

----------------------------------------------
--------------- COMPATIBILIDAD ----------------
----------------------------------------------

Este mod sustituye algunas clases básicas y no es compatible con otros mods que hacen lo mismo. Estos son:
* UIArmory_MainMenu
* UIInventory_Implants

----------------------------------------------
----------------- NOTAS ----------------------
----------------------------------------------

CLASES NUEVAS Y REMODELADAS

TIRADOR PRECISO: aunque es similar al tirador preciso del juego básico, el jugador también puede elegir Disparo instantáneo, que transforma al tirador en un tirador móvil. Empieza con Vista de pelotón.
COMANDO: un fusilero puro, con una pistola como arma auxiliar. Empieza con Dales caña.
ASALTO: un especialista en el manejo de la escopeta, similar al asalto de EU/EW, con una espada como arma secundaria. Empieza con Correr y disparar.
NINJA: un especialista en el sigilo, la movilidad y el manejo de la espada. Puede utilizar fusiles o escopetas como arma principal. Empieza con Fantasma.
ESPECIALISTA: similar al especialista del juego básico. Empieza con Protocolo de control y Protocolo de ayuda.
ARTILLERO: utiliza un cañón y una pistola. Las mejoras se centran en distintos disparos especiales.
GRANADERO: utiliza un fusil o una escopeta como arma principal y un lanzagranadas como arma secundaria. Añade una serie de habilidades que permiten al granadero especializarse en granadas de apoyo o dañinas.

Añadir este mod a una campaña en curso no cambiará los soldados existentes, y solo los nuevos soldados se clasificarán según los nuevos árboles de clase. Muchas de estas mejoras también pueden adquirirse en el centro de guerra avanzada.

NUEVAS MEJORAS

Campos de absorción
Agresión
Entrega por aire
Contención de zona
Bastión
Dejad que vengan
Centro de masas
Cercano y personal
Especialista en cuerpo a cuerpo
Encuentros cercanos
Disparo decisivo
Percepción de combate
Adrenalina de combate
Comisario
Encubierto
Despiadado
Fuego cíclico
Control de daños
Una posición de primera
Zona de peligro
Humo denso
Percepción de la profundidad
Doble tiro
Soporte vital de emergencia
Evasivo
Ejecutor
Condicionamiento extra
Cirujano de campaña
Cegador
Flecha
Kit completo
Movimiento fantasmal
Fuego de roce
Pistolero
Objetivo difícil
Granadas pesadas
Dispara y huye
Pupilas hiperreactivas
Luchador cercano
Interferencia
Telón de acero
Piel de hierro
Instinto asesino
Kubikuri
Letal
Dales caña
Reflejos relámpago_LW
Solitaria
Blanco fijado
Lobo solitario
Discreción
Disparo de precisión
Despliegue rápido
Reacción rápida
Aguante
Correr y disparar_LW
Salvador
Centinela_LW
Corte_LW
Disparo de posta
Macrófagos inteligentes
Granada de humo
Disparo instantáneo
Arma estable
Granadas aguijoneadoras
Contención_LW
Sentido táctico
Fuego transversal
Recortada
Troyano
Disparo en marcha
Voluntad de sobrevivir

Nuevos objetos, disponibles como botín durante las misiones
SCP: Percepción de la profundidad
SCP: Pupilas hiperreactivas
SCP: Percepción de combate
SCP: Adrenalina de combate
SCP: Campos de absorción
SCP: Control de daños
SCP: Escudo corporal
SCP: Soporte vital de emergencia
SCP: Piel de hierro
SCP: Macrófagos inteligentes