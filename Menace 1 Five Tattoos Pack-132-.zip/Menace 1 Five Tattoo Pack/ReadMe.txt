﻿Mod pretty much self explanatory. Add 7 New tattoos to the base game.
As always backup any save games, before installing mod.