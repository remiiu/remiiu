﻿Long War Fähigkeiten-Pack
Von Long War Studios
http://www.longwarstudios.com

Dieser Mod umfasst über 70 neue und überarbeitete Fähigkeiten für Soldaten, Ausrüstung und Aliens, erweitert die Benutzeroberfläche, um drei Fähigkeiten pro Soldatenrang zur Auswahl stellen zu können sowie neue Soldatenränge anzeigen zu können, überarbeitet die vier Grundklassen in nun sieben und führt 10 neue PKS-Objekte mit eigenen Vorteilen ein. Die Spieler können mithilfe dieser Fähigkeiten eigene Klassen erstellen.

Die taktische Benutzeroberfläche -- die Liste der aktivierbaren Fähigkeitensymbole -- wird ebenfalls überarbeitet, um mehr als 14 Fähigkeiten auf einmal benutzen zu können.

INSTALLATIONSANLEITUNG
Steam Workshop: Abonniere den Mod auf der  Workshop-Seite von Long War Studios.

Manuell/Nexus: Kopiere den Ordner LW_PerkPack aus dem Zip-Archiv mit allen darin enthaltenen Inhalten in deine Version des Ordners C:\Program Files (x86)\Steam\steamapps\common\XCOM 2\XComGame\Mods.

Zum Spielen:
Wähle den LW_PerkPack-Mod im Launcher. 

Hinweis: Dieser Mod verfügt über einige per Optionsmenü konfigurierbare Einstellungen, die nur angezeigt werden, wenn die Long War Toolbox installiert ist. Für die Primärfunktion dieses Mods wird die Toolbox jedoch nicht benötigt.

----------------------------------------------
----------------- CREDITS --------------------
----------------------------------------------

Design Lead / Programmer: John Lumpkin
Technical Lead: Rachel "Amineri" Norman
Artwork: Dana Henderson (http://www.danaillustration.com/)
Playtesting: Tim "Bilfdoffle" Evans

---------------------------------------------
------------------ RECHTE -------------------
---------------------------------------------

Modder dürfen sämtlichen Code sowie andere Ressourcen dieses Mods für eigene Projekte verwenden, solange Long War Studios an den entsprechenden Stellen als Autor genannt wird.

----------------------------------------------
--------------- KOMPATIBILITÄT ---------------
----------------------------------------------

Dieser Mod überschreibt einige Standardklassen und ist nicht kompatibel mit anderen Mods, die dieselben Klassen überschreiben. Überschriebene Klassen:
* UIArmory_MainMenu
* UIInventory_Implants

----------------------------------------------
---------------- HINWEISE --------------------
----------------------------------------------

NEUE UND ÜBERARBEITETE KLASSEN

SCHARFSCHÜTZE -- Gleicht dem Scharfschützen aus dem Standardspiel, die Spieler können ihn jedoch mithilfe von 'Schnellschuss' in einen mobilen Präzisionsschützen verwandeln. Beginnt mit Truppsicht.
RANGER -- Ein reiner Gewehrschütze mit einer Pistole als Zweitwaffe. Beginnt mit Leichtfüßig.
STURM -- Ein Schrotflintenspezialist (ähnlich dem Sturmsoldaten aus EU/EW) mit einem Schwert als Zweitwaffe. Beginnt mit Sturm und Schuss.
SHINOBI -- Ein Spezialist für Verborgenheit, Mobilität und Schwerter. Kann Gewehre oder Schrotflinten als Primärwaffe tragen. Beginnt mit Phantom.
SPEZIALIST -- Gleicht dem Spezialisten aus dem Standardspiel. Beginnt mit Übernahme- und Hilfsprotokoll.
SCHÜTZE -- Trägt eine Kanone und eine Pistole. Fähigkeiten konzentrieren sich auf eine Vielzahl von Spezialschüssen.
GRENADIER -- Trägt ein Gewehr oder eine Schrotflinte als Primärwaffe und einen Granatwerfer als Sekundärwaffe. Fügt eine Reihe von Fähigkeiten hinzu, um den Grenadier auf Unterstützungs- oder Schadensgranaten zu spezialisieren.

Das Hinzufügen dieses Mods zu einer laufenden Kampagne hat keinen Einfluss auf bestehende Soldaten und neue Soldaten werden ausschließlich den neuen Klassenbäumen zugewiesen. Viele Fähigkeiten können zudem im Fortschrittlichen Kriegszentrum erworben werden.

NEUE FÄHIGKEITEN

Absorptionsfelder
Aggression
Luftabwurf
Bereichsunterdrückung
Bastion
Lasst sie kommen
Volltreffer
Aus nächster Nähe
Nahkampfspezialist
Nahkampfbegegnungen
Entscheidender Schuss
Kampfscharfsinn
Kriegsrausch
Kommissar
Verdeckt
Gnadenlos
Zyklischer Beschuss
Schadenskontrolle
Höhenvorteil
Gefahrenzone
Dichter Rauch
Tiefenwahrnehmung
Doppelschuss
Notfall-Lebenserhaltung
Ausweichmanöver
Scharfrichter
Konditionierung
Feldsanitäter
Blender
Flèche
Volle Ausrüstung
Geistläufer
Streifschüsse
Revolverheld
Schwieriges Ziel
Schwere Granaten
Überfallangriff
Hyperreaktive Pupillen
Nahkämpfer
Störung
Eiserner Vorhang
Stahlhaut
Killerinstinkt
Kubikiri
Tödlich
Leichtfüßig
Blitzschnelle Reflexe (LW)
Abriegelung
Anvisieren
Einzelgänger
Gut gedeckt
Präzisionsschuss
Schnelleinsatz
Blitzreaktion
Widerstandskraft
Sturm und Schuss (LW)
Erretter
Sentinel (LW)
Schwerthieb (LW)
Flintenschuss
Intelligente Makrophagen
Rauchgranate
Schnellschuss
Waffe stabilisieren
Stachelgranaten
Unterdrückung
Taktisches Gespür
Eröffnungsfeuer
Trenchgun
Trojaner
Ruhiger Schuss
Überlebenswille

Neue Gegenstände (als Beute bei Einsätzen sammelbar)
PKS: Tiefenwahrnehmung
PKS: Hyperreaktive Pupillen
PKS: Kampfscharfsinn
PKS: Kriegsrausch
PKS: Absorptionsfelder
PKS: Schadenskontrolle
PKS: Körperschutzschild
PKS: Notfall-Lebenserhaltung
PKS: Stahlhaut
PKS: Intelligente Makrophagen